<?php

session_start();

require_once 'config.php';

// update values for brand enteries
if (isset($_POST['up_brands'])) {
  $bname = $_POST['bname'];
  $bmodel = $_POST['bmodel'];
  $id = $_POST['b_id'];
  $optics->updateBrand($bname,$bmodel, $id);
 // header("location: ../brands.php");
}

// update values for lens enteries
if (isset($_POST['up_lens'])) {
  $lname = $_POST['lname'];
  $ltype = $_POST['ltype'];
  $id = $_POST['l_id'];
  $optics->updateLens($lname,$ltype,$id);
  header("location: ../lenses.php");
}

// update values for frames enteries
if (isset($_POST['up_frames'])) {
  $f_brand = $_POST['f_brand'];
  $f_type = $_POST['f_type'];
  $id = $_POST['f_id'];
  $optics->updateFrames($f_brand,$f_type, $id);
  header("location: ../frames.php");
}

// update values for sunglasses enteries
if (isset($_POST['up_sunglasses'])) {
  $su_customerId = $_POST['c_id'];
  $su_customerName = $_POST['c_name'];
  $su_phone = $_POST['c_number'];
  $su_date = $_POST['date'];
  $su_brand = $_POST['s_brand'];
  $su_model = $_POST['s_model'];
  $su_id = $_POST['su_id'];

  $optics->updateSunglas($su_customerId,$su_customerName,$su_phone,$su_date,$su_brand,$su_model,$su_id);
  header("location: ../sunglasses.php");
}

// update values for Contactlenses enteries
if (isset($_POST['lens_update'])) {

  $cl_customerId = $_POST['c_id'];
  $cl_customerName = $_POST['c_name'];
  $cl_phone = $_POST['c_number'];
  $cl_date = $_POST['date'];
  $cl_lens = $_POST['lens'];
  $cl_r_sph_dist = $_POST['re_dist_sph'];
  $cl_r_sph_near = $_POST['re_near_sph'];
  $cl_r_cyl_dist = $_POST['re_dist_cyl'];
  $cl_r_cyl_near = $_POST['re_near_cyl'];
  $cl_r_axis_dist = $_POST['re_dist_axis'];
  $cl_r_axis_near = $_POST['re_near_axis'];
  $cl_l_sph_dist = $_POST['le_dist_sph'];
  $cl_l_sph_near = $_POST['le_near_sph'];
  $cl_l_cyl_dist = $_POST['le_dist_cyl'];
  $cl_l_cyl_near = $_POST['le_near_cyl'];
  $cl_l_axis_dist = $_POST['le_dist_axis'];
  $cl_l_axis_near = $_POST['le_near_axis'];
  $cl_totalAmout = $_POST['t_amount'];
  $cl_advancedAmt = $_POST['a_amount'];
  $cl_balanceAmt = $_POST['b_amount'];
  $cl_id = $_POST['cl_id'];

  $optics->updateContactLens($cl_customerId,$cl_customerName,$cl_phone,$cl_date,$cl_lens,$cl_r_sph_dist,$cl_r_sph_near,$cl_r_cyl_dist,$cl_r_cyl_near,$cl_r_axis_dist,$cl_r_axis_near,$cl_l_sph_dist,$cl_l_sph_near,$cl_l_cyl_dist,$cl_l_cyl_near,$cl_l_axis_dist,$cl_l_axis_near,$cl_totalAmout,$cl_advancedAmt,$cl_balanceAmt,$cl_id);
  header("location: ../contactlense_view.php");
}

// update values for spectacles enteries
if (isset($_POST['specs_update'])) {

  $sp_customerId = $_POST['c_id'];
  $sp_customerName = $_POST['c_name'];
  $sp_phone = $_POST['c_number'];
  $sp_date = $_POST['date'];
  $sp_frame = $_POST['frame'];
  $sp_brand = $_POST['brand'];
  $sp_lense = $_POST['lens'];
  $sp_r_sph_dist = $_POST['re_dist_sph'];
  $sp_r_sph_near = $_POST['re_near_sph'];
  $sp_r_cyl_dist = $_POST['re_dist_cyl'];
  $sp_r_cyl_near = $_POST['re_near_cyl'];
  $sp_r_axis_dist = $_POST['re_dist_axis'];
  $sp_r_axis_near = $_POST['re_near_axis'];
  $sp_l_sph_dist = $_POST['le_dist_sph'];
  $sp_l_sph_near = $_POST['le_near_sph'];
  $sp_l_cyl_dist = $_POST['le_dist_cyl'];
  $sp_l_cyl_near = $_POST['le_near_cyl'];
  $sp_l_axis_near = $_POST['le_dist_axis'];
  $sp_l_axis_dist = $_POST['le_near_axis'];
  $sp_totalAmount = $_POST['t_amount'];
  $sp_advancedAmt = $_POST['a_amount'];
  $sp_balanceAmt = $_POST['b_amount'];
  $sp_id = $_POST['sp_id'];

  $optics->updateSpecs($sp_customerId,$sp_customerName,$sp_phone,$sp_date,$sp_frame,$sp_brand,$sp_lense,$sp_r_sph_dist,$sp_r_sph_near,$sp_r_cyl_dist,$sp_r_cyl_near,$sp_r_axis_dist,$sp_r_axis_near,$sp_l_sph_dist,$sp_l_sph_near,$sp_l_cyl_dist,$sp_l_cyl_near,$sp_l_axis_near,$sp_l_axis_dist,$sp_totalAmount,$sp_advancedAmt,$sp_balanceAmt,$sp_id);
  header("location: ../spectacles_view.php");
}

// update values for enquire enteries
if (isset($_POST['upd_enquires'])) {

  $id = $_POST['e_id'];
  $e_name = $_POST['e_name'];
  $e_phone = $_POST['e_phone'];
  $e_date = $_POST['e_date'];
  $e_for = $_POST['e_for'];
  $e_desc = $_POST['e_desc'];

  $optics->updateEnquire($e_name,$e_phone,$e_date,$e_for,$e_desc,$id);
  header("location: ../enquires_view.php");
}

// update values for brand order enteries
if (isset($_POST['brands_update'])) {
  
  $table = 'order_entry_brands';
  $brandValues = $optics->fetchValues($table);
  
  $id=$_POST['bo_id'];
  $b_names = $_POST['b_names'];
  $b_model = $_POST['b_model'];
  $b_quantity = $_POST['b_quantity'];
  $myval=$value['b_quantity']+$b_quantity;
  $optics->updateFramesOrder($b_names,$b_model,$myval);
  header("location: ../brand_stock.php");

  
  $b_names = $_POST['b_names'];
  $b_model = $_POST['b_model'];
  $b_quantity = $_POST['b_quantity'];
  $lensValues =$optics->updateborder($b_names,$b_model,$b_quantity,$id);
  header("location: ../brand_stock.php");
}
// update values for lens order enteries
if (isset($_POST['lensorder_update'])) {
//echo '<pre>'; print_r($_POST); die();
$table = 'order_entry_lens';
$lensValues = $optics->fetchValues($table);
foreach($lensValues as $value)
{
  $id = $_POST['lo_id'];
  $l_name = $_POST['l_name'];
  $l_type = $_POST['l_type'];
  $l_quantity = $_POST['l_quantity'];
  $Added_value=$value['l_quantity']+$l_quantity;
   $optics->updateLensOrder($l_name,$l_type,$Added_value,$id);
  }
 header("location: ../lense_stock.php");
}

// update values for frames order enteries
if (isset($_POST['frameStockUpdate'])) {
  $table = 'order_entry_frames';
  $frameValues = $optics->fetchValues($table);
foreach($frameValues as $value)
{
  $id = $_POST['fo_id'];
  $f_name = $_POST['f_name'];
  $f_model = $_POST['f_model'];
  $f_quantity = $_POST['f_quantity'];
  $Added_value=$value['f_quantity']+$f_quantity;
  $optics->updateFramesOrder($f_name,$f_model,$Added_value,$id);
  header("location: ../frame_stock.php");
}
}

if (isset($_POST['brands_update_stock'])) {
  $table ='order_entry_brands';
  $brandValues = $optics->fetchValues($table);
foreach($brandValues as $value)
{
  $id = $_POST['bo_id'];
  $b_name = $_POST['b_names'];
  $b_model = $_POST['b_model'];
  $b_quantity = $_POST['b_quantity'];
  echo $Added_value= $value['b_quantity']+$b_quantity;
  $optics->updateBrandOrder($b_name,$b_model,$Added_value,$id);
  header("location: ../brand_stock.php");
}
}
 
?>