<?php

class rstClass {
	private $db;

  function __construct($db_con){
    $this->db = $db_con;
  }
// user regisatration
  public function InsertRst_Config($projectname,$projecttype,$ipaddress,$internetstatus,$username, $password,$role,$status,$logintime,$table) {
    try {
      $stmt = $this->db->prepare("INSERT INTO config(project_name,project_type,ip_address,internet_status,username,password,role,status,login_time) VALUES (:project_name,:project_type,:ip_address,:internet_status,:username,:password,:role,:login_time)");
       $stmt->bindParam(':project_name',$projectname);
      $stmt->bindParam(':project_type',$projecttype);
      $stmt->bindParam(':ip_address',$ipaddress);
      $stmt->bindParam(':internet_status',$internetstatus);
      $stmt->bindParam(':username',$username);
      $stmt->bindParam(':password',$password);
      $stmt->bindParam(':role',$role);
      $stmt->bindParam(':role',$status);
      $stmt->bindParam(':login_time',$logintime);
      $stmt->execute();
      return $stmt;
    } catch (PDOException $e){
      echo $e->getMessage();
    }
  }

 // insert in insert participant  table
public function InsertRst_Participant($Pname,$age,$address,$religion,$education,$occupation,$gravida,$trimester,$familytype,$familyincome,$socioecoclass,$rationcardtype,$diet) {
    try {
      $stmt = $this->db->prepare("INSERT INTO participant(p_name,age,address,religion,education,occupation,gravida,trimester,family_type,family_income,socio_eco_class,ration_card_type,diet) VALUES (:p_name,:age,:address,:religion,:education,:occupation,:gravida,:trimester,:family_type,:family_income,:socio_eco_class,:ration_card_type,:diet)");
      $stmt->bindParam(':p_name',$pname);
      $stmt->bindParam(':age',$age);
      $stmt->bindParam(':address',$address);
      $stmt->bindParam(':religion',$religion);
      $stmt->bindParam(':education',$education);
      $stmt->bindParam(':occupation',$occupation);
      $stmt->bindParam(':gravida',$gravida);
      $stmt->bindParam(':trimester',$trimester);
      $stmt->bindParam(':family_type',$familytype);
      $stmt->bindParam(':family_income',$familyincome);
      $stmt->bindParam(':socio_eco_class',$socioecoclass);
      $stmt->bindParam(':ration_card_type',$rationcardtype);
      $stmt->bindParam(':diet',$diet);
      $stmt->execute();
      return $stmt;
    } catch (PDOException $e){
      echo $e->getMessage();
    }
  }

//insert into 
 public function InsertRst_QtnTbl($qname,$opt1,$opt2,$opt3,$opt4,$opt5,$opt6,$opt7,$opt8,$status) {
    try {
      $stmt = $this->db->prepare("INSERT INTO question_tbl(q_name,opt_1,opt_2,opt_3,opt_4,opt_5,opt_6,opt_7,opt_8,status) VALUES (:qname,:opt1,:opt2,:opt3,:opt4,:opt5,:opt6,:opt7,:opt8,:status)");
      $stmt->bindParam(':qname',$qname);
      $stmt->bindParam(':opt1',$opt1);
      $stmt->bindParam(':opt2',$opt2);
      $stmt->bindParam(':opt3',$opt3);
      $stmt->bindParam(':opt4',$opt4);
      $stmt->bindParam(':opt5',$opt5);
      $stmt->bindParam(':opt6',$opt6);
      $stmt->bindParam(':opt7',$opt7);
      $stmt->bindParam(':opt8',$opt8);
      $stmt->bindParam(':status',$status);
      $stmt->execute();
      return $stmt;
    } catch (PDOException $e){
      echo $e->getMessage();
    }
  }

 //insert in result table
  public function InsertRst_Result_tbl($options,$longans,$createddate) {
    try {
      $stmt = $this->db->prepare("INSERT INTO result_tbl(options,long_ans,created_date) VALUES (:options,:long_ans,:created_date)");
      $stmt->bindParam(':options',$options);
      $stmt->bindParam(':long_ans',$longans);
      $stmt->bindParam(':created_date',$createddate);
      $stmt->execute();
      return $stmt;
    } catch (PDOException $e){
      echo $e->getMessage();
    }
  }

// Insert tables Close and Select Tables Begins

// Fetch Values Generally
  public function RstfetchValues($table) {
    try{
      $stmt = $this->db->prepare("SELECT * FROM $table");
      $stmt->execute();
      $result = $stmt->fetchAll();
      return $result;
    } catch (PDOException $e){
      echo $e->getMessage();
    }
  }

// Retrieve specefic field from specefic table: for id generation
  public function fetchLastIntered($table, $id) {
    try{
      $stmt = $this->db->prepare("SELECT * FROM $table ORDER BY $id DESC LIMIT 1");
      $stmt->execute();
      $result = $stmt->fetch(PDO::FETCH_ASSOC);
      return $result;
    } catch (PDOException $e){
      echo $e->getMessage();
    }
  }

// Select Config Table
  public function SltRst_Config($projectname,$projecttype,$ipaddress,$internetstatus,$username, $password,$role,$status,$logintime,$table) {
    try {
      $stmt = $this->db->prepare("SELECT project_name,project_type,ip_address,internet_status,username,password,role,status,login_time FROM $table");
      $stmt->bindParam(':project_name',$projectname);
      $stmt->bindParam(':project_type',$projecttype);
      $stmt->bindParam(':ip_address',$ipaddress);
      $stmt->bindParam(':internet_status',$internetstatus);
      $stmt->bindParam(':username',$username);
      $stmt->bindParam(':password',$password);
      $stmt->bindParam(':role',$role);
      $stmt->bindParam(':status',$status);
      $stmt->bindParam(':login_time',$logintime);
      $stmt->execute();
      $result = $stmt->fetch();

      return $result;
    } 
    catch (PDOException $e){
      echo $e->getMessage();
    }
  }



  // retrieve all specefic table fields : for edit purpose
  public function editView($table, $cid, $id) {
    try{
      $stmt = $this->db->prepare("SELECT * FROM $table WHERE $cid=:id");
      $stmt->bindParam(':id',$id);
      $stmt->execute();
      $result = $stmt->fetch(PDO::FETCH_ASSOC);
      return $result;
    } catch (PDOException $e){
      echo $e->getMessage();
    }
  }
  // Select tables end End Delete Tables Begins


  //General Delet Table
  public function deleteValue($table) {
    try {
      $stmt = $this->db->prepare("DELETE FROM $table");
      $stmt->execute();
      return $stmt;
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }

//select general table
  public function StockOut($table) {
    try {
      $stmt = $this->db->prepare("SELECT count(*) FROM $table");
      $stmt->execute();
      $rows = $stmt->fetchColumn();
      return $rows;
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }
// Delete Tables End and Update tables begins

//update begins
  // update data for config table

  public function UpdateRst_config($projectid,$projectname,$projecttype,$ipaddress,$internetstatus,$username,$password,$role,$status,
    $logintime) {
    try {
      $stmt = $this->db->prepare("UPDATE config SET project_name=:project_name,project_type=:project_type,ip_address=:ip_address,internet_status=:internet_status,username=:username,password=:password,
      role=:role,status=:status,login_time=:login_time WHERE project_id=:project_id");
      $stmt->bindParam(':project_id', $projectid);
      $stmt->bindParam(':project_name', $projectname);
      $stmt->bindParam(':project_type', $projecttype);
      $stmt->bindParam(':ip_address', $ipaddress);
      $stmt->bindParam(':internet_status', $internetstatus);
      $stmt->bindParam(':username', $username);
      $stmt->bindParam(':password', $password);
      $stmt->bindParam(':role', $role);
      $stmt->bindParam(':status', $status);
      $stmt->bindParam(':login_time', $login_time);
      $stmt->execute();
      return $stmt;
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }

  // update data for paticipant
  public function UpdateRst_Participant($pid,$pname,$age,$address,$religion,$education,$occupation,$gravida,$trimester,$familytype,$familyincome,$socioecoclass,$rationcardtype,$diet) {
    try {
      $stmt = $this->db->prepare("UPDATE participant SET p_name=:p_name,age=:age,address=:address,religion=:religion,education=:education,occupation=:occupation,gravida=:gravida,trimester=:trimester,family_type=:family_type,family_income=:family_income,socio_eco_class=:socio_eco_class,ration_card_type=:ration_card_type,diet=:diet WHERE p_id=:p_id");
      $stmt->bindParam(':p_name', $pname);
      $stmt->bindParam(':age', $age);
      $stmt->bindParam(':address', $address);
      $stmt->bindParam(':religion', $religion);
      $stmt->bindParam(':education', $education);
      $stmt->bindParam(':occupation', $occupation);
      $stmt->bindParam(':gravida', $gravida);
      $stmt->bindParam(':trimester', $trimester);
      $stmt->bindParam(':family_type', $familytype);
      $stmt->bindParam(':family_income', $familyincome);
      $stmt->bindParam(':socio_eco_class', $socioecoclass);
      $stmt->bindParam(':ration_card_type', $ration_card_type);
      $stmt->bindParam(':diet', $diet);
      $stmt->bindParam(':p_id', $pid);

      $stmt->execute();
      return $stmt;
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }
  
      // update data for question_tbl
  public function UpdateRst_Qtntbl($qid,$qname,$opt1,$opt2,$opt3,$opt4,$opt5,$opt6,$opt7,$opt8,$status) {
    try {
      $stmt = $this->db->prepare("UPDATE question_tbl SET q_name=:q_name,opt_1=:opt_1,opt_2=:opt_2,opt_3=:opt_3,opt_4=:opt_4,opt_5=:opt_5,opt_6=:opt_6,opt_7=:opt_7,opt_8=:opt_8,status=:status WHERE q_id=:q_id" );

      $stmt->bindParam(':q_name', $qname);
      $stmt->bindParam(':opt_1', $opt1);
      $stmt->bindParam(':opt_2', $opt2);
      $stmt->bindParam(':opt_3', $opt3);
      $stmt->bindParam(':opt_4', $opt4);
      $stmt->bindParam(':opt_5', $opt5);
      $stmt->bindParam(':opt_6', $opt6);
      $stmt->bindParam(':opt_7', $opt7);
      $stmt->bindParam(':opt_8', $opt8);
      $stmt->bindParam(':status', $status)
      $stmt->bindParam(':q_id', $qid);
      $stmt->execute();
      return $stmt;
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }
  
      // update data for result_tbl
  public function UpdateRst_resulttbl($rid,$pid,$qid,$options,$longans,$createddate) {
    try {
      $stmt = $this->db->prepare("UPDATE result_tbl SET q_id=:q_id,p_id=:p_id,options=:options,created_date=:created_date WHERE result_id=:result_id");
      $stmt->bindParam(':q_id', $qid);
      $stmt->bindParam(':p_id', $pid);
      $stmt->bindParam(':options', $options);
      $stmt->bindParam(':long_ans', $longans);
      $stmt->bindParam(':created_date', $createddate);
      $stmt->bindParam(':result_id', $rid);

      $stmt->execute();
      return $stmt;
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }  
  // update data for brand entry
  public function updatePassword($uid,$password) {
    try {
      $stmt = $this->db->prepare("UPDATE users SET password=:password WHERE id=:uid");
      $stmt->bindParam(':password', $password);
      $stmt->bindParam(':uid', $uid);
      $stmt->execute();
      return $stmt;
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }



}

?>